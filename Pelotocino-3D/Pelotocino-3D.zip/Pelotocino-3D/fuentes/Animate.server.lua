-- Procedural R15 fallback for this standalone model. No external animation IDs.
-- Disable this Script before using your own Animation Editor / Animator clips.
local model = script.Parent
local humanoid = model:WaitForChild("Humanoid")
local RunService = game:GetService("RunService")
local motors, rest = {}, {}
for _, object in ipairs(model:GetDescendants()) do
    if object:IsA("Motor6D") then
        motors[object.Name] = object
        rest[object.Name] = object.C0
    end
end
local speed, phase = 0, 0
humanoid.Running:Connect(function(value) speed = value end)
local connection
connection = RunService.Heartbeat:Connect(function(dt)
    if not model.Parent or humanoid.Health <= 0 then connection:Disconnect() return end
    local state = humanoid:GetState()
    local airborne = state == Enum.HumanoidStateType.Jumping or state == Enum.HumanoidStateType.Freefall
    local moving = speed > 0.5
    local running = speed > 15
    phase = phase + dt * (running and 12 or 8)
    local amplitude = moving and (running and 0.78 or 0.46) or 0
    local target = {}
    for _, side in ipairs({"Left", "Right"}) do
        local sign = side == "Left" and 1 or -1
        local swing = math.sin(phase) * sign * amplitude
        target[side .. "Hip"] = airborne and -0.25 or swing
        target[side .. "Knee"] = airborne and 0.45 or math.max(0, -swing) * 0.95
        target[side .. "Ankle"] = airborne and -0.18 or -math.max(0, -swing) * 0.35
        target[side .. "Shoulder"] = airborne and -0.7 or -swing * 0.7
        target[side .. "Elbow"] = airborne and -0.3 or -math.max(0, swing) * 0.4
    end
    for name, motor in pairs(motors) do
        local goal = rest[name] * CFrame.Angles(target[name] or 0, 0, 0)
        motor.C0 = motor.C0:Lerp(goal, math.min(1, dt * 14))
    end
end)
