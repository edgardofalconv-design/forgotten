from PIL import Image
from pathlib import Path
base=Path(__file__).resolve().parent/'avatar_assets'
shirt=Image.open(base/'MotorcycleShirt.png').convert('RGBA');pants=Image.open(base/'BlackJeans.png').convert('RGBA')
skin=(240,238,233,255)
def paste(atlas,source,src,dst):
 patch=source.crop(src);atlas.alpha_composite(patch,dst)
# The R15 meshes share a 384x256 torso atlas and 256x256 limb atlases.
torso=Image.new('RGBA',(384,256),(23,24,25,255))
for src,dst in [((231,74,359,202),(0,64)),((363,74,427,202),(128,64)),((427,74,555,202),(192,64)),((165,74,229,202),(320,64)),((231,8,359,72),(0,0)),((231,208,359,272),(0,192))]:paste(torso,shirt,src,dst)
torso.save(base/'TorsoAtlas.png')
for side in ['Left','Right']:
 for limb,source in [('Arm',shirt),('Leg',pants)]:
  atlas=Image.new('RGBA',(256,256),skin if limb=='Arm' else (18,19,20,255))
  if limb=='Leg':
   for y in range(192,256):
    for x in range(256):atlas.putpixel((x,y),skin)
  starts=[506,308,374,440] if side=='Left' else [151,217,19,85]
  for i,x in enumerate(starts):paste(atlas,source,(x,355,x+64,483),(i*64,64))
  front=308 if side=='Left' else 217
  paste(atlas,source,(front,289,front+64,353),(0,0));paste(atlas,source,(front,485,front+64,549),(192,192))
  if limb=='Arm':
   # Unused UV gutters around shoulder caps need a dark sleeve guard band.
   for y in range(64):
    for x in range(256):
     if x>=64:atlas.putpixel((x,y),(24,25,26,255))
  atlas.save(base/(side+limb+'Atlas.png'))
