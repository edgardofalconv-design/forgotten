import bpy, math, random, json, os, sys, xml.etree.ElementTree as E
from mathutils import Vector, Matrix
from pathlib import Path

BASE=Path(__file__).resolve().parent
OUT=Path(os.environ.get('PELOTOCINO_OUT',str(BASE.parent if BASE.name=='fuentes' else BASE.parent/'output'/'Pelotocino-3D'))); OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
random.seed(31)
WHITE=(.87,.85,.82); BLACK=(.034,.038,.042); BLUE=(.055,.27,.55); DENIM=(.035,.047,.061)
BROWN=(.29,.17,.095); TAN=(.42,.29,.18); METAL=(.49,.44,.36); HAIR=(.27,.105,.036)
visual=[]; centers={}; sizes={}; bones=[]
# All design data use Roblox coordinates: Y up, -Z forward. Blender uses Z up.
Q=Matrix(((1,0,0),(0,0,-1),(0,1,0)))
def v(v):return Q@Vector(v)
def rot(axis,angle):return Matrix.Rotation(angle,3,axis)
def add(name,pos,size,color,bone,shape='box',R=None,material='SmoothPlastic'):
    R=R or Matrix.Identity(3)
    visual.append(dict(name=name,p=list(pos),s=list(size),c=list(color),bone=bone,shape=shape,R=[list(row) for row in R],material=material))
def rounded(name,p,s,c,bone,r=.06,material='SmoothPlastic',R=None):
    R=R or Matrix.Identity(3); p=Vector(p); a,b,d=s; r=min(r,min(s)/2-.001)
    def emit(n,local,sz,shape='box',RR=None):add(name+n,p+R@Vector(local),sz,c,bone,shape,R@(RR or Matrix.Identity(3)),material)
    emit('_coreZ',(0,0,0),(a-2*r,b-2*r,d))
    emit('_coreX',(0,0,0),(a,b-2*r,d-2*r))
    emit('_coreY',(0,0,0),(a-2*r,b,d-2*r))
    for x in [-1,1]:
      for y in [-1,1]:
       for z in [-1,1]:emit('_corner',(x*(a/2-r),y*(b/2-r),z*(d/2-r)),(r*2,)*3,'sphere')
    for axis in range(3):
      others=[i for i in range(3) if i!=axis]
      for k in [-1,1]:
       for l in [-1,1]:
        pp=[0,0,0];pp[others[0]]=k*(s[others[0]]/2-r);pp[others[1]]=l*(s[others[1]]/2-r)
        rr=Matrix.Identity(3) if axis==0 else rot('Z',math.pi/2) if axis==1 else rot('Y',math.pi/2)
        emit('_edge',pp,(s[axis]-2*r,2*r,2*r),'cylinder',rr)
def line(name,points,radius,c,bone,material='SmoothPlastic'):
    for a,b in zip(points,points[1:]):
      a,b=Vector(a),Vector(b);delta=b-a
      R=Vector((1,0,0)).rotation_difference(delta.normalized()).to_matrix()
      add(name,(a+b)/2,(delta.length,2*radius,2*radius),c,bone,'cylinder',R,material)
    for p in points:add(name,p,(2*radius,)*3,c,bone,'sphere',material=material)
def body(name,p,s):centers[name]=Vector(p);sizes[name]=s
body('HumanoidRootPart',(0,2.9,0),(1.6,1.5,.7))
body('LowerTorso',(0,2.72,0),(1.48,.5,.7));body('UpperTorso',(0,3.46,0),(1.64,.98,.75));body('Head',(0,4.67,0),(1.38,1.32,1.2))
rounded('Head',(0,4.67,0),(1.38,1.32,1.2),WHITE,'Head',.22)
rounded('Tshirt',(0,3.43,-.035),(1.5,1.05,.74),BLUE,'UpperTorso',.10,'Fabric')
rounded('Waist',(0,2.73,0),(1.48,.50,.73),BLACK,'LowerTorso',.07,'Fabric')
# Open black jacket and folded lapels, no extra accessories.
for sign in [-1,1]:
    rounded('JacketPanel',(sign*.56,3.44,-.10),(.48,1.08,.78),BLACK,'UpperTorso',.07,'Fabric')
    rounded('Lapel',(sign*.32,3.78,-.52),(.16,.49,.075),(.022,.026,.03),'UpperTorso',.025,'Fabric',rot('Z',sign*-.27))
    line('JacketSeam',[(sign*.34,3.0,-.504),(sign*.34,3.40,-.504),(sign*.38,3.7,-.504)],.008,(.08,.085,.09),'UpperTorso')
rounded('JacketBack',(0,3.46,.35),(1.5,1.05,.13),BLACK,'UpperTorso',.045,'Fabric')
# Visible blue neckline: rounded white neck with blue collar.
add('Neck',(0,4.01,0),(.49,.35,.49),WHITE,'Head','cylinder',rot('Z',math.pi/2))
line('BlueCollar',[(.29*math.cos(t),3.91-.13*math.sin(t),-.426) for t in [i*math.pi/16 for i in range(17)]],.035,(.12,.37,.65),'UpperTorso')
# Small dark chest graphic: its exact lettering is not legible in the reference.
for x,y,sx,sy in [(-.18,3.42,.19,.13),(.03,3.43,.25,.12),(.19,3.48,.14,.21),(-.08,3.32,.22,.09)]:
    rounded('ChestGraphic',(x,y,-.419),(sx,sy,.015),(.015,.034,.055),'UpperTorso',.009)
for x in [-.23,.17]:line('ChestGraphic',[(x,3.34,-.433),(x-.035,3.22,-.433),(x+.08,3.19,-.433),(x+.12,3.27,-.433)],.018,(.015,.034,.055),'UpperTorso')
for sign,side in [(-1,'Left'),(1,'Right')]:
    x=sign*1.13
    body(side+'UpperArm',(x,3.45,0),(.58,.96,.64))
    body(side+'LowerArm',(x,2.69,0),(.52,.56,.56))
    body(side+'Hand',(x,2.18,-.02),(.58,.47,.49))
    rounded(side+'Sleeve',(x,3.45,0),(.62,.96,.69),BLACK,side+'UpperArm',.16,'Fabric')
    rounded(side+'Cuff',(x,3.02,-.005),(.64,.12,.71),(.045,.05,.054),side+'UpperArm',.025,'Fabric')
    rounded(side+'Forearm',(x,2.69,0),(.53,.58,.55),WHITE,side+'LowerArm',.115)
    # Classic Roblox C-grip with a real open gap and rounded ends.
    pts=[]
    for i in range(17):
      t=math.radians(-40+280*i/16)
      pts.append((x+sign*.235*math.cos(t),2.18+.235*math.sin(t),-.055))
    line(side+'Grip',pts,.113,WHITE,side+'Hand')
    legx=sign*.43
    body(side+'UpperLeg',(legx,2.0,0),(.78,1.02,.76))
    body(side+'LowerLeg',(legx,1.0,0),(.76,.98,.73))
    body(side+'Foot',(legx,.31,-.13),(.82,.4,1.04))
    rounded(side+'JeansUpper',(legx,2,0),(.8,1.04,.79),DENIM,side+'UpperLeg',.07,'Fabric')
    rounded(side+'JeansLower',(legx,1.0,0),(.78,1.0,.76),DENIM,side+'LowerLeg',.055,'Fabric')
    rounded(side+'Hem',(legx,.56,0),(.80,.12,.78),(.046,.055,.065),side+'LowerLeg',.025,'Fabric')
    for seg,cy in [('UpperLeg',2.0),('LowerLeg',1.)]:
      for i in range(60):
        xx=legx+random.uniform(-.35,.35); yy=cy+random.uniform(-.43,.43)
        add('DenimWeave',(xx,yy,-.401 if seg=='UpperLeg' else -.385),(.009,random.uniform(.012,.044),.004),(.083,.096,.11),side+seg,R=rot('Z',-.45),material='Fabric')
      line('DenimSideSeam',[(legx+sign*.382,cy-.40,-.18),(legx+sign*.382,cy+.40,-.18)],.008,(.12,.125,.13),side+seg)
    rounded(side+'Sneaker',(legx,.31,-.14),(.82,.43,1.07),WHITE,side+'Foot',.16)
    rounded(side+'Sole',(legx,.14,-.14),(.86,.19,1.1),(.77,.76,.74),side+'Foot',.055)
    for i in range(15):add('SoleRib',(legx-.37+i*.052,.15,-.695),(.014,.13,.018),(.9,.88,.85),side+'Foot')
# Face directly modelled in 3D, so it requires no inaccessible decal assets.
for x in [-.205,.205]:add('Eye',(x,4.81,-.602),(.086,.20,.026),(.012,.012,.014),'Head','sphere')
line('Smile',[(.255*math.cos(t),4.49-.23*math.sin(t),-.608) for t in [i*math.pi/24 for i in range(25)]],.024,(.012,.012,.014),'Head')
# Layered swept bacon hair: curved locks and thin warm ridges, never voxel cubes.
add('HairCrown',(0,5.27,.035),(1.45,.58,1.21),HAIR,'Head','sphere')
def lock(name,pts,width,depth,c):
    # Continuous curved locks rather than separate bead-like ellipsoids.
    smooth=[];vv=[Vector(p) for p in pts]
    for i in range(len(vv)-1):
      a=vv[max(0,i-1)];b=vv[i];cc=vv[i+1];d=vv[min(len(vv)-1,i+2)]
      for j in range(2):
       t=j/2;smooth.append(.5*((2*b)+(-a+cc)*t+(2*a-5*b+4*cc-d)*t*t+(-a+3*b-3*cc+d)*t*t*t))
    smooth.append(vv[-1]);line(name,smooth,width*.5,c,'Head')
    line(name+'Highlight',[(p[0]-.02,p[1]+.015,p[2]-width*.48) for p in smooth],.012,(.53,.25,.10),'Head')
for i in range(9):
    x=-.64+i*.16
    start=(x*.5-.12,5.44+(.08 if i%3==0 else 0),.12)
    endy=5.02+(.10 if i%3==0 else 0)
    pts=[start,(x*.77,5.50,-.15),(x,5.31,-.48),(x+.04,5.17,-.61),(x+.04,endy,-.59)]
    # Leave the face open in the center, as in the supplied image.
    if 3<=i<=4:pts=pts[:-1];pts[-1]=(pts[-1][0],5.09,-.62)
    lock('FrontHair',pts,.17,.17,(.30+i%3*.035,.115+i%3*.022,.039))
for side in [-1,1]:
    for i in range(4):
      z=-.28+i*.24
      lock('SideHair',[(side*.45,5.43,z*.5),(side*.67,5.27,z),(side*.735,4.99,z),(side*.72,4.76+(i%2)*.08,z)],.18,.20,(.26+i*.025,.09+i*.013,.031))
for i in range(7):
    x=-.57+i*.19
    lock('BackHair',[(x*.65,5.44,.24),(x,5.26,.57),(x,5.00,.63),(x+.025,4.77,.60)],.20,.20,(.27+(i%3)*.023,.1,.034))
# Basic brown backpack with lid, two front pockets, buckles, handle and shoulder straps.
rounded('Backpack',(0,3.39,.78),(1.17,1.30,.55),BROWN,'UpperTorso',.15,'Leather')
rounded('BackpackFlap',(0,3.85,1.065),(1.15,.49,.13),TAN,'UpperTorso',.095,'Leather')
for x in [-.285,.285]:
    rounded('BackpackPocket',(x,3.14,1.105),(.49,.46,.16),(.34,.215,.127),'UpperTorso',.07,'Leather')
    rounded('PocketFlap',(x,3.31,1.20),(.48,.12,.04),TAN,'UpperTorso',.03,'Leather')
    rounded('PocketStrap',(x,3.15,1.228),(.085,.36,.035),TAN,'UpperTorso',.015,'Leather')
    rounded('PocketBuckle',(x,3.18,1.254),(.12,.11,.025),METAL,'UpperTorso',.015,'Metal')
for x in [-.67,.67]:rounded('BackpackSidePocket',(x,3.26,.79),(.22,.55,.40),TAN,'UpperTorso',.065,'Leather')
rounded('FlapStrap',(0,3.65,1.16),(.13,.46,.045),(.34,.22,.13),'UpperTorso',.018,'Leather')
rounded('FlapBuckle',(0,3.66,1.198),(.20,.16,.035),METAL,'UpperTorso',.025,'Metal')
rounded('BuckleInset',(0,3.66,1.22),(.11,.085,.012),BROWN,'UpperTorso',.012)
line('BackpackHandle',[(-.20,4.02,.75),(-.20,4.16,.76),(0,4.21,.76),(.20,4.16,.76),(.20,4.02,.75)],.045,TAN,'UpperTorso','Leather')
for sign in [-1,1]:
    line('ShoulderStrap',[(sign*.57,3.0,-.48),(sign*.64,3.35,-.52),(sign*.72,3.72,-.48),(sign*.72,3.98,-.20),(sign*.64,4.02,.35),(sign*.50,3.85,.63)],.09,TAN,'UpperTorso','Leather')
    rounded('StrapBuckle',(sign*.65,3.47,-.624),(.21,.20,.045),METAL,'UpperTorso',.025,'Metal')
    rounded('StrapBuckleInset',(sign*.65,3.47,-.65),(.135,.10,.018),BROWN,'UpperTorso',.015)

# R15 anatomical topology and world-space joint pivots.
bones=[('Root','HumanoidRootPart','LowerTorso',(0,2.72,0)),('Waist','LowerTorso','UpperTorso',(0,2.97,0)),('Neck','UpperTorso','Head',(0,4.00,0))]
for s,sgn in [('Left',-1),('Right',1)]:
    bones += [(s+'Shoulder','UpperTorso',s+'UpperArm',(sgn*.84,3.9,0)),(s+'Elbow',s+'UpperArm',s+'LowerArm',(sgn*1.13,2.97,0)),(s+'Wrist',s+'LowerArm',s+'Hand',(sgn*1.13,2.41,0)),(s+'Hip','LowerTorso',s+'UpperLeg',(sgn*.43,2.51,0)),(s+'Knee',s+'UpperLeg',s+'LowerLeg',(sgn*.43,1.49,0)),(s+'Ankle',s+'LowerLeg',s+'Foot',(sgn*.43,.51,0))]

# XML is a real Roblox model containing persistent Parts, meshes, Motor6Ds and Humanoid.
root=E.Element('roblox',{'version':'4'});E.SubElement(root,'External').text='null';E.SubElement(root,'External').text='nil'
serial=0
def item(cl,parent,name):
    global serial
    serial+=1;i=E.SubElement(parent,'Item',{'class':cl,'referent':f'RBX{serial}'});p=E.SubElement(i,'Properties');prop(p,'string','Name',name);return i,p
def prop(p,t,n,value):e=E.SubElement(p,t,{'name':n});e.text=str(value);return e
def vec(p,n,val):e=E.SubElement(p,'Vector3',{'name':n});[E.SubElement(e,k).__setattr__('text',str(float(x))) for k,x in zip(['X','Y','Z'],val)];return e
def cf(p,n,pos=(0,0,0),R=None):
    R=R or Matrix.Identity(3);e=E.SubElement(p,'CoordinateFrame',{'name':n})
    for k,x in zip(['X','Y','Z'],pos):E.SubElement(e,k).text=str(float(x))
    for i in range(3):
     for j in range(3):E.SubElement(e,f'R{i}{j}').text=str(float(R[i][j]))
    return e
model,mp=item('Model',root,'Pelotocino');refs={};bodyitems={}
def native_part(parent,name,pos,size,color,shape='box',R=None,transparent=0,massless=True,collide=False,mat='SmoothPlastic'):
    i,p=item('Part',parent,name);vec(p,'size',size);cf(p,'CFrame',pos,R)
    rgb=[max(0,min(255,round(x*255))) for x in color]
    prop(p,'Color3uint8','Color3uint8',(rgb[0]<<16)|(rgb[1]<<8)|rgb[2])
    for n,val in [('Anchored',False),('CanCollide',collide),('CanTouch',collide),('CanQuery',True),('Massless',massless)]:prop(p,'bool',n,str(val).lower())
    prop(p,'float','Transparency',transparent);prop(p,'token','Material',{'SmoothPlastic':272,'Fabric':1312,'Leather':272,'Metal':1088}.get(mat,272));prop(p,'token','shape',{'box':1,'sphere':0,'cylinder':2}[shape])
    prop(p,'token','TopSurface',10);prop(p,'token','BottomSurface',10)
    return i,p
for n,pos in centers.items():
    i,p=native_part(model,n,pos,sizes[n],WHITE,transparent=1,massless=n!='HumanoidRootPart',collide=n in ['UpperTorso','LowerTorso'])
    refs[n]=i.get('referent');bodyitems[n]=i
prop(mp,'Ref','PrimaryPart',refs['HumanoidRootPart'])
hum,hp=item('Humanoid',model,'Humanoid');prop(hp,'token','RigType',1);prop(hp,'float','HipHeight',2.15);prop(hp,'float','WalkSpeed',12);prop(hp,'float','JumpPower',45);prop(hp,'bool','UseJumpPower','true');prop(hp,'bool','RequiresNeck','true');prop(hp,'string','DisplayName','Pelotocino');item('Animator',hum,'Animator')
for name,a,b,pivot in bones:
    ji,jp=item('Motor6D',bodyitems[b],name);prop(jp,'Ref','Part0',refs[a]);prop(jp,'Ref','Part1',refs[b]);cf(jp,'C0',Vector(pivot)-centers[a]);cf(jp,'C1',Vector(pivot)-centers[b])
    for bn in [a,b]:
      ai,ap=item('Attachment',bodyitems[bn],name+'RigAttachment');cf(ap,'CFrame',Vector(pivot)-centers[bn])
for bn,an,position in [('Head','HatAttachment',(0,.66,0)),('Head','HairAttachment',(0,.50,0)),('Head','FaceFrontAttachment',(0,0,-.6)),('UpperTorso','BodyBackAttachment',(0,0,.4)),('LeftHand','LeftGripAttachment',(0,0,0)),('RightHand','RightGripAttachment',(0,0,0))]:
    ai,ap=item('Attachment',bodyitems[bn],an);cf(ap,'CFrame',position)
for n,val in [('BodyHeightScale',1),('BodyWidthScale',1),('BodyDepthScale',1),('HeadScale',1),('BodyTypeScale',0),('BodyProportionScale',0)]:ni,np=item('NumberValue',hum,n);prop(np,'double','Value',val)
# Group removable visual layers with Accessory containers, permanently welded for this standalone rig.
groups={}
for name in ['Hair','Backpack','Clothing','Face','Body']:
    if name in ['Hair','Backpack']:
      ac,acp=item('Accessory',model,name);prop(acp,'token','AccessoryType',2 if name=='Hair' else 8)
      bn='Head' if name=='Hair' else 'UpperTorso'
      handle,hprop=native_part(ac,'Handle',centers[bn],(.1,.1,.1),WHITE,transparent=1)
      weld,wp=item('WeldConstraint',handle,'AccessoryBind');prop(wp,'Ref','Part0',refs[bn]);prop(wp,'Ref','Part1',handle.get('referent'));prop(wp,'bool','Enabled','true')
      ai,ap=item('Attachment',handle,'HairAttachment' if name=='Hair' else 'BodyBackAttachment');cf(ap,'CFrame',(0,.50,0) if name=='Hair' else (0,0,.4))
      groups[name]=ac
    else:groups[name]=item('Model',model,name)[0]
for idx,o in enumerate(visual):
    n=o['name'];group='Hair' if 'Hair' in n else 'Backpack' if any(k in n for k in ['Backpack','Pocket','Flap','Buckle','Strap']) else 'Face' if n in ['Eye','Smile'] else 'Body' if any(k in n for k in ['Head','Forearm','Grip','Neck']) else 'Clothing'
    i,p=native_part(groups[group],n+f'_{idx}',o['p'],o['s'],o['c'],o['shape'],Matrix(o['R']),mat=o['material'])
    w,wp=item('WeldConstraint',i,'Bind_'+o['bone']);prop(wp,'Ref','Part0',refs[o['bone']]);prop(wp,'Ref','Part1',i.get('referent'));prop(wp,'bool','Enabled','true')
animate=(BASE/'Animate.server.lua').read_text()
script,sp=item('Script',model,'Animate');prop(sp,'ProtectedString','Source',animate);prop(sp,'bool','Disabled','false')
E.indent(root);E.ElementTree(root).write(OUT/'Pelotocino.rbxmx',encoding='utf-8',xml_declaration=False)

# Blender source and glTF: join geometry by bone, rigidly weighted to an actual armature.
mats={}
def material(color,kind):
    key=(tuple(color),kind)
    if key in mats:return mats[key]
    m=bpy.data.materials.new(kind+'_'+str(len(mats)));m.diffuse_color=(*color,1);m.use_nodes=True
    bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*color,1);bs.inputs['Roughness'].default_value=.76 if kind in ['Fabric','Leather'] else .4
    if kind=='Metal':bs.inputs['Metallic'].default_value=.7
    mats[key]=m;return m
meshes={}
for shape in ['box','sphere','cylinder']:
    if shape=='box':bpy.ops.mesh.primitive_cube_add(size=1)
    elif shape=='sphere':bpy.ops.mesh.primitive_uv_sphere_add(segments=20,ring_count=12,radius=.5)
    else:bpy.ops.mesh.primitive_cylinder_add(vertices=12,radius=.5,depth=1,rotation=(0,math.pi/2,0));bpy.ops.object.transform_apply(location=False,rotation=True,scale=False)
    ob=bpy.context.object;meshes[shape]=ob.data.copy();bpy.data.objects.remove(ob,do_unlink=True)
objects=[];surface_groups={}
for idx,o in enumerate(visual):
    mesh=meshes[o['shape']].copy();ob=bpy.data.objects.new(o['name'],mesh);bpy.context.collection.objects.link(ob)
    # Shapes are authored in native XYZ before conversion; CFrame and dimensions map together.
    ob.matrix_world=Q.to_4x4()@Matrix.Translation(Vector(o['p']))@Matrix(o['R']).to_4x4()@Matrix.Diagonal(Vector((*o['s'],1)))
    ob.data.materials.append(material(o['c'],o['material']))
    if o['shape']!='box':
      for poly in ob.data.polygons:poly.use_smooth=o['shape']=='sphere' or len(poly.vertices)==4
    vg=ob.vertex_groups.new(name=o['bone']);vg.add(list(range(len(mesh.vertices))),1,'REPLACE');objects.append(ob)
    surface_groups.setdefault((o['bone'],tuple(o['c']),o['material']),[]).append(ob)
# Weld the interchange surfaces volumetrically: internal overlaps of native solids
# must not produce coplanar shading artifacts in the exported triangle meshes.
objects=[]
for (bone,col,kind),obs in surface_groups.items():
    bpy.ops.object.select_all(action='DESELECT')
    for ob in obs:ob.select_set(True)
    bpy.context.view_layer.objects.active=obs[0];bpy.ops.object.join();ob=bpy.context.object
    bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
    # Keep sub-voxel stitches/graphics as their original visible geometry.
    if len(ob.data.vertices)>200 and max(ob.dimensions)>.12:
      re=ob.modifiers.new('Fuse surfaces','REMESH');re.mode='VOXEL';re.voxel_size=.018 if kind!='Metal' else .012;re.use_smooth_shade=True
      bpy.ops.object.modifier_apply(modifier=re.name)
      sm=ob.modifiers.new('Surface polish','SMOOTH');sm.factor=.65;sm.iterations=3;bpy.ops.object.modifier_apply(modifier=sm.name)
    ob.vertex_groups.clear();vg=ob.vertex_groups.new(name=bone);vg.add(list(range(len(ob.data.vertices))),1,'REPLACE');objects.append(ob)
bpy.ops.object.select_all(action='DESELECT')
for ob in objects:ob.select_set(True)
bpy.context.view_layer.objects.active=objects[0];bpy.ops.object.join();skin=bpy.context.object;skin.name='Pelotocino_RenderMesh';bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
# UVs plus included packed palette texture ensure the interchange file carries real textures.
palette=bpy.data.images.new('Pelotocino_MaterialPalette',width=64,height=64,alpha=True)
pixels=[0.0]*(64*64*4);keys=list(mats)
for iy in range(64):
 for ix in range(64):
  k=min((iy//8)*8+ix//8,len(keys)-1);col=keys[k][0];off=(iy*64+ix)*4;pixels[off:off+4]=[*col,1]
palette.pixels=pixels;palette.filepath_raw=str(OUT/'Pelotocino_palette.png');palette.file_format='PNG';palette.save();palette.pack()
uv=skin.data.uv_layers.active or skin.data.uv_layers.new(name='PaletteUV')
for poly in skin.data.polygons:
    m=skin.data.materials[poly.material_index];ind=list(mats.values()).index(m);u=(ind%8+.5)/8;vv=(ind//8+.5)/8
    for li in poly.loop_indices:uv.data[li].uv=(u,vv)
for m in mats.values():
    tex=m.node_tree.nodes.new('ShaderNodeTexImage');tex.image=palette;m.node_tree.links.new(tex.outputs['Color'],m.node_tree.nodes.get('Principled BSDF').inputs['Base Color'])
# Armature local bone axes intentionally independent from Roblox Motor6D axes.
bpy.ops.object.select_all(action='DESELECT');bpy.ops.object.armature_add();rig=bpy.context.object;rig.name='Pelotocino_R15';bpy.ops.object.mode_set(mode='EDIT');rig.data.edit_bones.remove(rig.data.edit_bones[0]);eb={}
for n in centers:
    b=rig.data.edit_bones.new(n);b.head=v(centers[n]);b.tail=b.head+Vector((0,0,.25));eb[n]=b
for name,a,b,pivot in bones:eb[b].head=v(pivot);eb[b].tail=eb[b].head+Vector((0,0,.25));eb[b].parent=eb[a]
bpy.ops.object.mode_set(mode='OBJECT');mod=skin.modifiers.new('R15 rigid skin','ARMATURE');mod.object=rig;skin.parent=rig
rig['Roblox_Rig']='R15 topology; Roblox runtime skeleton lives in Pelotocino.rbxmx'
# Three preview clips in the source and interchange file; runtime Studio tests remain required.
for clip,duration,amp in [('Walk',30,.45),('Run',20,.75),('Jump',36,.30)]:
    rig.animation_data_create();rig.animation_data.action=bpy.data.actions.new(clip)
    for frame in range(0,duration+1,5):
      phase=frame/duration*2*math.pi
      for side,sign in [('Left',1),('Right',-1)]:
       for suffix,factor in [('UpperLeg',1),('LowerLeg',-.6),('UpperArm',-.65),('LowerArm',.25)]:
        pb=rig.pose.bones[side+suffix];pb.rotation_mode='XYZ';pb.rotation_euler=(sign*amp*math.sin(phase)*factor,0,0) if clip!='Jump' else (amp*math.sin(frame/duration*math.pi)*factor,0,0);pb.keyframe_insert('rotation_euler',frame=frame)
    track=rig.animation_data.nla_tracks.new();track.name=clip;track.strips.new(clip,1,rig.animation_data.action);rig.animation_data.action=None
for track in rig.animation_data.nla_tracks:track.mute=True
for pb in rig.pose.bones:pb.rotation_euler=(0,0,0)
bpy.context.scene.frame_set(1)
# Save modelling scene before adding preview-only lighting and camera.
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'Pelotocino.blend'),compress=True)
bpy.ops.object.select_all(action='DESELECT');skin.select_set(True);rig.select_set(True);bpy.context.view_layer.objects.active=rig
for track in rig.animation_data.nla_tracks:track.mute=False
bpy.ops.export_scene.gltf(filepath=str(OUT/'Pelotocino.glb'),export_format='GLB',use_selection=True,export_animations=True,export_animation_mode='NLA_TRACKS',export_yup=True,export_apply=False)
for track in rig.animation_data.nla_tracks:track.mute=True
for pb in rig.pose.bones:pb.rotation_euler=(0,0,0)
bpy.context.scene.frame_set(1)
# Render the actual model from front/back to inspect the deliverable.
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=24;scene.cycles.use_denoising=False
scene.world.color=(.12,.12,.12);scene.render.resolution_x=900;scene.render.resolution_y=1000;scene.render.resolution_percentage=100
bpy.ops.mesh.primitive_plane_add(size=200);floor=bpy.context.object;floor.name='PreviewFloor';floor.data.materials.append(material((.055,.062,.075),'SmoothPlastic'))
for loc,power,size in [((4,-5,9),1100,5),((-4,-2,5),800,4),((1,4,8),1500,3)]:
    bpy.ops.object.light_add(type='AREA',location=loc);light=bpy.context.object;light.data.energy=power;light.data.shape='DISK';light.data.size=size;light.rotation_euler=(Vector((0,0,3))-light.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add();cam=bpy.context.object;scene.camera=cam;cam.data.type='ORTHO';cam.data.ortho_scale=6.7
for label,loc in [('frente',(8,16,8)),('espalda',(-8,-16,8))]:
    cam.location=loc;cam.rotation_euler=(Vector((0,0,2.85))-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(OUT/('Vista_'+label+'.png'));bpy.ops.render.render(write_still=True)
(OUT/'scene.json').write_text(json.dumps({'parts':visual,'centers':{k:list(val) for k,val in centers.items()},'joints':bones},indent=1))
(OUT/'model_stats.json').write_text(json.dumps({'visual_parts':len(visual),'r15_body_parts':15,'root_parts':1,'motor6d':len(bones),'blender_vertices':len(skin.data.vertices),'blender_polygons':len(skin.data.polygons),'materials':len(mats),'runtime_studio_verified':False},indent=2))
print('DELIVERY_STATS', (OUT/'model_stats.json').read_text())
