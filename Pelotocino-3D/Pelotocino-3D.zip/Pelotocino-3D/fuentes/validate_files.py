import xml.etree.ElementTree as E, json, struct, hashlib, os
from pathlib import Path
BASE=Path(__file__).resolve().parent
p=Path(os.environ.get('PELOTOCINO_OUT',str(BASE.parent if BASE.name=='fuentes' else BASE.parent/'output'/'Pelotocino-3D'))); r=E.parse(p/'Pelotocino.rbxmx').getroot();items=list(r.iter('Item'))
refs={i.attrib['referent']:i for i in items};assert len(refs)==len(items)
def props(i):return {v.attrib['name']:v for v in i.find('Properties')}
for i in items:
 for v in i.find('Properties'):
  if v.tag=='Ref':assert v.text in refs or v.text in ('null','nil'),v.text
motors=[i for i in items if i.attrib['class']=='Motor6D'];assert len(motors)==15
expected={'LowerTorso','UpperTorso','Head'}|{s+t for s in ('Left','Right') for t in ('UpperArm','LowerArm','Hand','UpperLeg','LowerLeg','Foot')}
root=items[0];direct={props(i)['Name'].text:i for i in root.findall('Item')}
assert expected <= set(direct)
assert props(direct['Humanoid'])['RigType'].text=='1'
def xyz(v):return [float(v.find(c).text) for c in ('X','Y','Z')]
for i in motors:
 d=props(i);a=props(refs[d['Part0'].text]);b=props(refs[d['Part1'].text]);pa=xyz(a['CFrame']);pb=xyz(b['CFrame']);c0=xyz(d['C0']);c1=xyz(d['C1'])
 assert max(abs(pa[k]+c0[k]-pb[k]-c1[k]) for k in range(3))<1e-5
for i in items:
 d=props(i)
 if i.attrib['class'] in ('Part','MeshPart'):
  assert d['Anchored'].text=='false';assert all(x>0 for x in xyz(d['size']))
for name in ('Hair','Backpack'):
 assert direct[name].attrib['class']=='Accessory'
 assert any(props(x)['Name'].text=='Handle' for x in direct[name].findall('Item'))
data=(p/'Pelotocino.glb').read_bytes();magic,version,length=struct.unpack_from('<4sII',data);assert (magic,version,length)==(b'glTF',2,len(data))
length,kind=struct.unpack_from('<II',data,12);g=json.loads(data[20:20+length]);assert g['skins'] and g['meshes'] and len(g['animations'])>=3
assert len(g['skins'][0]['joints'])>=16
assert all('uri' not in b for b in g['buffers']);assert all('bufferView' in im for im in g['images'])
assert all('POSITION' in pr['attributes'] and 'JOINTS_0' in pr['attributes'] and 'WEIGHTS_0' in pr['attributes'] for mesh in g['meshes'] for pr in mesh['primitives'])
meshparts=[i for i in items if i.attrib['class']=='MeshPart'];assert len(meshparts)==14
assert all(props(i)['MeshContent'].find('uri').text.startswith('rbxassetid://') for i in meshparts)
assert direct['Shirt'].attrib['class']=='Shirt' and direct['Pants'].attrib['class']=='Pants'
report={'version':2,'xml_parse':'PASS','references':'PASS','r15_body_parts':len(expected),'motor6d':len(motors),'joint_rest_alignment':'PASS','accessories':'Hair, Backpack with Handles','baseparts_total':sum(i.attrib['class'] in ('Part','MeshPart') for i in items),'official_body_meshparts':len(meshparts),'official_clothing':'Blue and Black Motorcycle Shirt + Black Jeans with White Shoes','glb_parse':'PASS','glb_skin_joints':len(g['skins'][0]['joints']),'glb_animations':[a.get('name','') for a in g['animations']],'glb_embedded_textures':len(g['images']),'studio_import':'NOT RUN: Roblox Studio is not installed','runtime_animation':'NOT RUN in Roblox Studio','native_dependencies':'Official Roblox meshes and clothing load through Roblox CDN; no custom asset uploads','performance':'Accessory detailing still uses native primitives; profile in Studio before production'}
(p/'VERIFICACION.json').write_text(json.dumps(report,indent=2,ensure_ascii=False));print(json.dumps(report,indent=2))
