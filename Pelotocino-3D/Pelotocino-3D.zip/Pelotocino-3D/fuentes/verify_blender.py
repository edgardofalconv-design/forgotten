import bpy, json, os
from pathlib import Path
BASE=Path(__file__).resolve().parent
p=Path(os.environ.get('PELOTOCINO_OUT',str(BASE.parent if BASE.name=='fuentes' else BASE.parent/'output'/'Pelotocino-3D')))
bpy.ops.wm.open_mainfile(filepath=str(p/'Pelotocino.blend'))
rig=bpy.data.objects['Pelotocino_R15'];mesh=bpy.data.objects['Pelotocino_RenderMesh']
assert rig.type=='ARMATURE' and len(rig.data.bones)==16
assert len(mesh.data.vertices)>1000 and len(mesh.vertex_groups)==15
assert any(m.type=='ARMATURE' and m.object==rig for m in mesh.modifiers)
assert bpy.data.images['Pelotocino_MaterialPalette'].packed_file
assert {t.name for t in rig.animation_data.nla_tracks}=={'Walk','Run','Jump'}
checks={}
for track in rig.animation_data.nla_tracks:
 track.mute=False
 bpy.context.scene.frame_set(1);bpy.context.view_layer.update();a=rig.pose.bones['LeftUpperLeg'].matrix.copy()
 bpy.context.scene.frame_set(8);bpy.context.view_layer.update();b=rig.pose.bones['LeftUpperLeg'].matrix.copy()
 delta=sum(abs(a[i][j]-b[i][j]) for i in range(4) for j in range(4));assert delta>.01,(track.name,delta)
 checks[track.name]=dict(pose_changes=True,matrix_delta=round(delta,4));track.mute=True
report={'blend_reopens':True,'mesh_vertices':len(mesh.data.vertices),'bones':len(rig.data.bones),'weighted_vertex_groups':len(mesh.vertex_groups),'packed_texture':True,'animated_pose_checks':checks,'roblox_studio_execution':False}
(p/'BLENDER_VERIFICACION.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
