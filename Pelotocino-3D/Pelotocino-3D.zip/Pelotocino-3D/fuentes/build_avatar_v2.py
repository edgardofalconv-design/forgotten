import bpy, math, json, struct, re, os, shutil, xml.etree.ElementTree as E
from pathlib import Path
from mathutils import Matrix, Vector
BASE=Path(__file__).resolve().parent
OUT=Path(os.environ.get('PELOTOCINO_OUT',str(BASE.parent if BASE.name=='fuentes' else BASE.parent/'output'/'Pelotocino-3D')));OUT.mkdir(parents=True,exist_ok=True)
ASSETS=BASE/'avatar_assets'
meta=json.loads((ASSETS/'body_metadata.json').read_text())
Q=Matrix(((1,0,0),(0,0,-1),(0,1,0)))
def vec3(v):return Vector(v)
def native_to_blender(v):return Q@Vector(v)
def rotation(axis,a):return Matrix.Rotation(a,3,axis)
WHITE=(.94,.93,.91);BLACK=(.025,.027,.029);BROWN=(.24,.14,.078);TAN=(.36,.24,.14);METAL=(.47,.43,.35)
# Real Roblox Man meshes, scaled along anatomical axes into a lean avatar.
scales={}
for name in meta:
 if 'Torso' in name:s=(.70,.65,.61)
 elif 'UpperArm' in name:s=(.54,.78,.66)
 elif 'LowerArm' in name:s=(.54,.61,.59)
 elif 'Hand' in name:s=(.59,.50,.57)
 elif 'UpperLeg' in name:s=(.76,.70,.70)
 elif 'LowerLeg' in name:s=(.76,.78,.70)
 else:s=(.82,.48,.66)
 scales[name]=Vector(s)
def scaled_attachment(name,att):return Vector(meta[name]['attachments'][att])*scales[name]
centers={'LowerTorso':Vector((0,3,0))};sizes={name:Vector(m['size'])*scales[name] for name,m in meta.items()}
joints=[]
def connect(joint,a,b):
 aa=scaled_attachment(a,joint+'RigAttachment');bb=scaled_attachment(b,joint+'RigAttachment')
 pivot=centers[a]+aa;centers[b]=pivot-bb;joints.append((joint,a,b,pivot))
connect('Waist','LowerTorso','UpperTorso')
for side in ['Left','Right']:
 connect(side+'Shoulder','UpperTorso',side+'UpperArm');connect(side+'Elbow',side+'UpperArm',side+'LowerArm');connect(side+'Wrist',side+'LowerArm',side+'Hand')
 connect(side+'Hip','LowerTorso',side+'UpperLeg');connect(side+'Knee',side+'UpperLeg',side+'LowerLeg');connect(side+'Ankle',side+'LowerLeg',side+'Foot')
# Bring the soles to the ground without changing any rig rest alignment.
bottom=min(centers[s+'Foot'].y-sizes[s+'Foot'].y/2 for s in ['Left','Right']);shift=Vector((0,-bottom+.025,0))
for k in centers:centers[k]+=shift
joints=[(n,a,b,p+shift) for n,a,b,p in joints]
head_neck=Vector((0,-.59,0));neck=centers['UpperTorso']+scaled_attachment('UpperTorso','NeckRigAttachment')
centers['Head']=neck-head_neck;sizes['Head']=Vector((1.24,1.24,1.24));joints.append(('Neck','UpperTorso','Head',neck))
centers['HumanoidRootPart']=centers['LowerTorso']+Vector((0,.14,0));sizes['HumanoidRootPart']=Vector((1.15,1.5,.62));joints.insert(0,('Root','HumanoidRootPart','LowerTorso',centers['LowerTorso']+scaled_attachment('LowerTorso','RootRigAttachment')))
# Native primitive detailing is reserved for the head, face and compact backpack.
visual=[]
def add(name,p,s,c,bone,shape='box',R=None,kind='SmoothPlastic'):
 visual.append(dict(name=name,p=list(p),s=list(s),c=list(c),bone=bone,shape=shape,R=[list(row) for row in (R or Matrix.Identity(3))],kind=kind))
def rounded(name,p,s,c,bone,r=.04,kind='SmoothPlastic',R=None):
 R=R or Matrix.Identity(3);p=Vector(p);r=min(r,min(s)/2-.001);a,b,d=s
 def emit(n,local,sz,shape='box',rr=None):add(name+n,p+R@Vector(local),sz,c,bone,shape,R@(rr or Matrix.Identity(3)),kind)
 for sz in [(a-2*r,b-2*r,d),(a,b-2*r,d-2*r),(a-2*r,b,d-2*r)]:emit('_core',(0,0,0),sz)
 for x in [-1,1]:
  for y in [-1,1]:
   for z in [-1,1]:emit('_corner',(x*(a/2-r),y*(b/2-r),z*(d/2-r)),(2*r,)*3,'sphere')
 for axis in range(3):
  others=[i for i in range(3) if i!=axis]
  for k in [-1,1]:
   for l in [-1,1]:
    pp=[0,0,0];pp[others[0]]=k*(s[others[0]]/2-r);pp[others[1]]=l*(s[others[1]]/2-r)
    rr=Matrix.Identity(3) if axis==0 else rotation('Z',math.pi/2) if axis==1 else rotation('Y',math.pi/2)
    emit('_edge',pp,(s[axis]-2*r,2*r,2*r),'cylinder',rr)
def line(name,points,r,c,bone,kind='SmoothPlastic'):
 for a,b in zip(points,points[1:]):
  a,b=Vector(a),Vector(b);d=b-a
  if d.length<.00001:continue
  R=Vector((1,0,0)).rotation_difference(d.normalized()).to_matrix();add(name,(a+b)/2,(d.length,r*2,r*2),c,bone,'cylinder',R,kind)
 for p in points:add(name,p,(r*2,)*3,c,bone,'sphere',kind=kind)
head=centers['Head'];radius=.62
add('HeadCylinder',head,(1.04,1.24,1.24),WHITE,'Head','cylinder',rotation('Z',math.pi/2))
for sign in [-1,1]:add('HeadRim',head+Vector((0,sign*.52,0)),(1.24,.20,1.24),WHITE,'Head','sphere')
# Face follows the actual cylindrical surface rather than floating on a flat plate.
for x in [-.165,.165]:
 z=-math.sqrt(radius**2-x*x)-.011
 add('Eye',head+Vector((x,.12,z)),(.065,.155,.024),(.009,.009,.009),'Head','sphere')
pts=[]
for i in range(25):
 t=i/24*math.pi;x=.215*math.cos(t);y=-.135-.19*math.sin(t);z=-math.sqrt(radius**2-x*x)-.014;pts.append(head+Vector((x,y,z)))
line('Smile',pts,.018,(.009,.009,.009),'Head')
# Match the basic backpack from the original reference, with thinner straps.
torso=centers['UpperTorso'];pack=torso+Vector((0,-.03,.49))
rounded('Backpack',pack,(.91,1.08,.36),BROWN,'UpperTorso',.075,'Leather')
rounded('BackpackFlap',pack+Vector((0,.33,.215)),(.91,.40,.075),TAN,'UpperTorso',.045,'Leather')
for x in [-.225,.225]:
 rounded('BackpackPocket',pack+Vector((x,-.24,.255)),(.38,.35,.15),(.29,.18,.10),'UpperTorso',.045,'Leather')
 rounded('PocketFlap',pack+Vector((x,-.10,.34)),(.37,.085,.025),TAN,'UpperTorso',.012,'Leather')
 rounded('PocketStrap',pack+Vector((x,-.25,.345)),(.065,.26,.024),TAN,'UpperTorso',.01,'Leather')
 rounded('PocketBuckle',pack+Vector((x,-.22,.369)),(.085,.075,.018),METAL,'UpperTorso',.009,'Metal')
for x in [-.50,.50]:rounded('BackpackSidePocket',pack+Vector((x,-.13,.01)),(.15,.39,.28),TAN,'UpperTorso',.04,'Leather')
rounded('FlapStrap',pack+Vector((0,.20,.264)),(.095,.36,.028),(.26,.16,.085),'UpperTorso',.01,'Leather')
rounded('FlapBuckle',pack+Vector((0,.19,.29)),(.15,.13,.025),METAL,'UpperTorso',.012,'Metal')
rounded('BuckleInset',pack+Vector((0,.19,.306)),(.080,.062,.006),BROWN,'UpperTorso',.002)
line('BackpackHandle',[pack+Vector(p) for p in [(-.14,.51,0),(-.14,.62,0),(0,.66,0),(.14,.62,0),(.14,.51,0)]],.028,TAN,'UpperTorso','Leather')
for sign in [-1,1]:
 pts=[torso+Vector((sign*x,y,z)) for x,y,z in [(.39,-.47,-.315),(.46,-.07,-.37),(.52,.36,-.29),(.50,.63,-.06),(.43,.64,.25),(.34,.46,.45)]]
 line('ShoulderStrap',pts,.045,TAN,'UpperTorso','Leather')
 rounded('StrapBuckle',torso+Vector((sign*.46,-.02,-.419)),(.13,.145,.022),METAL,'UpperTorso',.014,'Metal')
 rounded('StrapBuckleInset',torso+Vector((sign*.46,-.02,-.434)),(.075,.073,.008),BROWN,'UpperTorso',.006)
# Pal Hair from Roblox. Its original UVs, mesh and texture are retained.
hairscale=Vector((.88,.924,.88));hairattach=Vector((0,.3499999,.24972776));hairpos=head+Vector((0,.50,0))-hairattach*hairscale

# XML authoring helpers.
root=E.Element('roblox',{'version':'4'});E.SubElement(root,'External').text='null';E.SubElement(root,'External').text='nil';serial=0

def prop(p,t,n,val):e=E.SubElement(p,t,{'name':n});e.text=str(val);return e

def item(cl,parent,name):
 global serial
 serial+=1;i=E.SubElement(parent,'Item',{'class':cl,'referent':f'RBX{serial}'});p=E.SubElement(i,'Properties');prop(p,'string','Name',name);return i,p

def vec(p,n,vals):
 e=E.SubElement(p,'Vector3',{'name':n})
 for k,val in zip(['X','Y','Z'],vals):E.SubElement(e,k).text=str(float(val))
 return e

def cf(p,n,pos=(0,0,0),R=None):
 e=E.SubElement(p,'CoordinateFrame',{'name':n});R=R or Matrix.Identity(3)
 for k,val in zip(['X','Y','Z'],pos):E.SubElement(e,k).text=str(float(val))
 for i in range(3):
  for j in range(3):E.SubElement(e,f'R{i}{j}').text=str(float(R[i][j]))
 return e

def content(p,name,uri):e=E.SubElement(p,'Content',{'name':name});E.SubElement(e,'uri').text=uri

def basepart(parent,cl,name,p,s,c,trans=0,collide=False,massless=True,R=None,kind='SmoothPlastic'):
 i,pp=item(cl,parent,name);vec(pp,'size',s);cf(pp,'CFrame',p,R);rgb=[round(a*255) for a in c];prop(pp,'Color3uint8','Color3uint8',(rgb[0]<<16)|(rgb[1]<<8)|rgb[2]);prop(pp,'float','Transparency',trans)
 for n,val in [('Anchored',False),('CanCollide',collide),('CanTouch',collide),('CanQuery',True),('Massless',massless)]:prop(pp,'bool',n,str(val).lower())
 prop(pp,'token','Material',1088 if kind=='Metal' else 272);return i,pp

def weld(parent,a,b,name='Bind'):
 w,wp=item('WeldConstraint',parent,name);prop(wp,'Ref','Part0',a);prop(wp,'Ref','Part1',b);prop(wp,'bool','Enabled','true')
model,mp=item('Model',root,'Pelotocino');refs={};bodyitems={}
for n,p in centers.items():
 ismesh=n in meta
 obj,pp=basepart(model,'MeshPart' if ismesh else 'Part',n,p,sizes[n],WHITE,trans=0 if ismesh else 1,massless=n!='HumanoidRootPart')
 if ismesh:
  content(pp,'MeshContent','rbxassetid://'+str(meta[n]['id']));vec(pp,'InitialSize',meta[n]['size']);prop(pp,'token','CollisionFidelity',3)
 else:prop(pp,'token','shape',1)
 refs[n]=obj.get('referent');bodyitems[n]=obj
prop(mp,'Ref','PrimaryPart',refs['HumanoidRootPart']);prop(bodyitems['HumanoidRootPart'].find('Properties'),'int','RootPriority',127)
h,pp=item('Humanoid',model,'Humanoid');prop(pp,'token','RigType',1);prop(pp,'float','HipHeight',centers['HumanoidRootPart'].y-.75);prop(pp,'float','WalkSpeed',12);prop(pp,'float','JumpPower',45);prop(pp,'bool','UseJumpPower','true');prop(pp,'bool','RequiresNeck','true');prop(pp,'bool','AutomaticScalingEnabled','false');prop(pp,'string','DisplayName','Pelotocino');item('Animator',h,'Animator')
for cl,field,aid in [('Shirt','ShirtTemplate',144076357),('Pants','PantsTemplate',398633811)]:
 garment,gp=item(cl,model,cl);content(gp,field,'rbxassetid://'+str(aid))
for name,a,b,pivot in joints:
 motor,jp=item('Motor6D',bodyitems[b],name);prop(jp,'Ref','Part0',refs[a]);prop(jp,'Ref','Part1',refs[b]);cf(jp,'C0',pivot-centers[a]);cf(jp,'C1',pivot-centers[b])
 for bn in [a,b]:
  att,ap=item('Attachment',bodyitems[bn],name+'RigAttachment');cf(ap,'CFrame',pivot-centers[bn])
for bn,an,p in [('Head','HairAttachment',(0,.5,0)),('Head','HatAttachment',(0,.62,0)),('Head','FaceFrontAttachment',(0,0,-.62)),('UpperTorso','BodyBackAttachment',(0,0,.33)),('LeftHand','LeftGripAttachment',(0,0,0)),('RightHand','RightGripAttachment',(0,0,0))]:
 att,ap=item('Attachment',bodyitems[bn],an);cf(ap,'CFrame',p)
# Invisible collision proxies retain stable simple hulls without custom physics cooking.
for n in ['UpperTorso','LowerTorso']:
 proxy,pp=basepart(bodyitems[n],'Part','CollisionHull',centers[n],sizes[n]*Vector((.83,.9,.85)),WHITE,trans=1,collide=True);prop(pp,'token','shape',1);weld(proxy,refs[n],proxy.get('referent'))
backpack,bp=item('Accessory',model,'Backpack');prop(bp,'token','AccessoryType',8)
handle,hp=basepart(backpack,'Part','Handle',torso,(.1,.1,.1),WHITE,trans=1);weld(handle,refs['UpperTorso'],handle.get('referent'));att,ap=item('Attachment',handle,'BodyBackAttachment');cf(ap,'CFrame',(0,0,.33))
face,fp=item('Model',model,'Face');headmodel,hmp=item('Model',model,'HeadGeometry')
for idx,o in enumerate(visual):
 n=o['name'];parent=face if n in ['Eye','Smile'] else headmodel if n.startswith('Head') else backpack
 obj,pp=basepart(parent,'Part',n+'_'+str(idx),o['p'],o['s'],o['c'],R=Matrix(o['R']),kind=o['kind']);prop(pp,'token','shape',{'box':1,'sphere':0,'cylinder':2}[o['shape']]);weld(obj,refs[o['bone']],obj.get('referent'))
hair,hp=item('Accessory',model,'Hair');prop(hp,'token','AccessoryType',2);handle,pp=basepart(hair,'Part','Handle',hairpos,(1.55,1.2,1.72),(1,1,1));prop(pp,'token','shape',1)
mesh,mpart=item('SpecialMesh',handle,'PalHairMesh');prop(mpart,'token','MeshType',5);content(mpart,'MeshContent','rbxassetid://83293901');content(mpart,'TextureContent','rbxassetid://6858317867');vec(mpart,'Scale',hairscale);vec(mpart,'VertexColor',(1,1,1));vec(mpart,'Offset',(0,0,0))
weld(handle,refs['Head'],handle.get('referent'));att,ap=item('Attachment',handle,'HairAttachment');cf(ap,'CFrame',hairattach*hairscale)
script,sp=item('Script',model,'Animate');prop(sp,'ProtectedString','Source',(BASE/'Animate.server.lua').read_text());prop(sp,'bool','Disabled','false')
E.indent(root);E.ElementTree(root).write(OUT/'Pelotocino.rbxmx',encoding='utf-8',xml_declaration=False)

# Blender imports the SAME real mesh files and UVs used by the native avatar.
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
materials={}
def make_material(name,color=(1,1,1),texture=None,rough=.72,metal=0):
 if name in materials:return materials[name]
 m=bpy.data.materials.new(name);m.use_nodes=True;bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*color,1);bs.inputs['Roughness'].default_value=rough;bs.inputs['Metallic'].default_value=metal
 if texture:
  im=bpy.data.images.load(str(ASSETS/texture),check_existing=True);im.pack();node=m.node_tree.nodes.new('ShaderNodeTexImage');node.image=im;m.node_tree.links.new(node.outputs['Color'],bs.inputs['Base Color'])
 materials[name]=m;return m

def read_mesh(path):
 data=path.read_bytes()
 if data.startswith(b'version 1.'):
  text=data.decode();groups=[list(map(float,g.split(','))) for g in re.findall(r'\[([^\]]+)\]',text)];factor=.5 if text.startswith('version 1.00') else 1
  vertices=[tuple(a*factor for a in g) for g in groups[::3]];normals=groups[1::3];uvs=[(g[0],1-g[1]) for g in groups[2::3]];faces=[(i,i+1,i+2) for i in range(0,len(vertices),3)];return vertices,faces,uvs,normals
 off=data.index(b'\n')+1;hs,vs,fs,nv,nf=struct.unpack_from('<HBBII',data,off);off+=hs
 vv=[struct.unpack_from('<8f',data,off+i*vs) for i in range(nv)];off+=nv*vs;faces=[struct.unpack_from('<III',data,off+i*fs) for i in range(nf)]
 return [v[:3] for v in vv],faces,[(v[6],1-v[7]) for v in vv],[v[3:6] for v in vv]
objects=[]
def build_mesh(name,path,p,scale,material,bone):
 vertices,faces,uvs,normals=read_mesh(path);coords=[native_to_blender(Vector(v)*scale+Vector(p)) for v in vertices]
 me=bpy.data.meshes.new(name);me.from_pydata(coords,[],faces);me.update();ob=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(ob);me.materials.append(material)
 uv=me.uv_layers.new(name='RobloxUV')
 for poly in me.polygons:
  poly.use_smooth=True
  for li in poly.loop_indices:uv.data[li].uv=uvs[me.loops[li].vertex_index]
 # Keep the authored normals; Man meshes intentionally contain sharp boundaries.
 transformed=[]
 for n in normals:transformed.append((Q@Vector((n[0]/scale[0],n[1]/scale[1],n[2]/scale[2]))).normalized())
 try:me.normals_split_custom_set_from_vertices(transformed)
 except Exception:pass
 vg=ob.vertex_groups.new(name=bone);vg.add(list(range(len(me.vertices))),1,'REPLACE');objects.append(ob);return ob
for name in meta:
 texture='TorsoAtlas.png' if 'Torso' in name else name[:4]+('Arm' if any(k in name for k in ['Arm','Hand']) else 'Leg')+'Atlas.png'
 if name.startswith('Left'):texture='Left'+('Arm' if any(k in name for k in ['Arm','Hand']) else 'Leg')+'Atlas.png' if 'Torso' not in name else texture
 if name.startswith('Right'):texture='Right'+('Arm' if any(k in name for k in ['Arm','Hand']) else 'Leg')+'Atlas.png' if 'Torso' not in name else texture
 build_mesh(name,ASSETS/(name+'.mesh'),centers[name],scales[name],make_material(texture,texture=texture),name)
build_mesh('PalHair',ASSETS/'PalHair.mesh',hairpos,hairscale,make_material('PalHair',texture='PalHair.png',rough=.65),'Head')
# Primitive detail groups are fused for clean mesh surfaces and then decimated.
primitive_meshes={}
for shape in ['box','sphere','cylinder']:
 if shape=='box':bpy.ops.mesh.primitive_cube_add(size=1)
 elif shape=='sphere':bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=16,radius=.5)
 else:bpy.ops.mesh.primitive_cylinder_add(vertices=32,radius=.5,depth=1,rotation=(0,math.pi/2,0));bpy.ops.object.transform_apply(location=False,rotation=True,scale=False)
 ob=bpy.context.object;primitive_meshes[shape]=ob.data.copy();bpy.data.objects.remove(ob,do_unlink=True)
groups={}
for o in visual:
 me=primitive_meshes[o['shape']].copy();ob=bpy.data.objects.new(o['name'],me);bpy.context.collection.objects.link(ob);ob.matrix_world=Q.to_4x4()@Matrix.Translation(Vector(o['p']))@Matrix(o['R']).to_4x4()@Matrix.Diagonal(Vector((*o['s'],1)))
 mat=make_material(str(o['c'])+o['kind'],o['c'],rough=.72,metal=.65 if o['kind']=='Metal' else 0);me.materials.append(mat)
 for poly in me.polygons:poly.use_smooth=o['shape']=='sphere' or len(poly.vertices)==4
 groups.setdefault((o['bone'],mat.name),[]).append(ob)
for (bone,matname),obs in groups.items():
 bpy.ops.object.select_all(action='DESELECT')
 for ob in obs:ob.select_set(True)
 bpy.context.view_layer.objects.active=obs[0];bpy.ops.object.join();ob=bpy.context.object;bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
 if len(obs)>2:
  re=ob.modifiers.new('Fuse accessory details','REMESH');re.mode='VOXEL';re.voxel_size=.012;re.use_smooth_shade=True;bpy.ops.object.modifier_apply(modifier=re.name)
  sm=ob.modifiers.new('Polish','SMOOTH');sm.factor=.5;sm.iterations=2;bpy.ops.object.modifier_apply(modifier=sm.name)
  dec=ob.modifiers.new('Reduce detail geometry','DECIMATE');dec.ratio=.12;bpy.ops.object.modifier_apply(modifier=dec.name)
 vg=ob.vertex_groups.new(name=bone);vg.add(list(range(len(ob.data.vertices))),1,'REPLACE');objects.append(ob)
bpy.ops.object.select_all(action='DESELECT')
for ob in objects:ob.select_set(True)
bpy.context.view_layer.objects.active=objects[0];bpy.ops.object.join();skin=bpy.context.object;skin.name='Pelotocino_RenderMesh';bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
# Real sixteen-bone R15 hierarchy with rigid per-body-part skinning.
bpy.ops.object.select_all(action='DESELECT');bpy.ops.object.armature_add();rig=bpy.context.object;rig.name='Pelotocino_R15';bpy.ops.object.mode_set(mode='EDIT');rig.data.edit_bones.remove(rig.data.edit_bones[0]);eb={}
for name,p in centers.items():
 b=rig.data.edit_bones.new(name);b.head=native_to_blender(p);b.tail=b.head+Vector((0,0,.20));eb[name]=b
for name,a,b,pivot in joints:eb[b].head=native_to_blender(pivot);eb[b].tail=eb[b].head+Vector((0,0,.20));eb[b].parent=eb[a]
bpy.ops.object.mode_set(mode='OBJECT');skin.parent=rig;mod=skin.modifiers.new('R15 skin','ARMATURE');mod.object=rig
for clip,duration,amp in [('Walk',30,.45),('Run',20,.75),('Jump',36,.30)]:
 rig.animation_data_create();rig.animation_data.action=bpy.data.actions.new(clip)
 for frame in range(0,duration+1,5):
  phase=frame/duration*2*math.pi
  for side,sign in [('Left',1),('Right',-1)]:
   for suffix,factor in [('UpperLeg',1),('LowerLeg',-.6),('UpperArm',-.65),('LowerArm',.25)]:
    pb=rig.pose.bones[side+suffix];pb.rotation_mode='XYZ';pb.rotation_euler=(sign*amp*math.sin(phase)*factor,0,0) if clip!='Jump' else (amp*math.sin(frame/duration*math.pi)*factor,0,0);pb.keyframe_insert('rotation_euler',frame=frame)
 track=rig.animation_data.nla_tracks.new();track.name=clip;track.strips.new(clip,1,rig.animation_data.action);rig.animation_data.action=None
for track in rig.animation_data.nla_tracks:track.mute=True
for pb in rig.pose.bones:pb.rotation_euler=(0,0,0)
bpy.context.scene.frame_set(1)
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'Pelotocino.blend'),compress=True)
bpy.ops.object.select_all(action='DESELECT');skin.select_set(True);rig.select_set(True);bpy.context.view_layer.objects.active=rig
for track in rig.animation_data.nla_tracks:track.mute=False
bpy.ops.export_scene.gltf(filepath=str(OUT/'Pelotocino.glb'),export_format='GLB',use_selection=True,export_animations=True,export_animation_mode='NLA_TRACKS',export_yup=True)
for track in rig.animation_data.nla_tracks:track.mute=True
for pb in rig.pose.bones:pb.rotation_euler=(0,0,0)
bpy.context.scene.frame_set(1)
# Neutral front and rear renders of the actual Blender model.
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=False;scene.world.color=(.25,.25,.25);scene.render.resolution_x=850;scene.render.resolution_y=1000;scene.render.resolution_percentage=100
bpy.ops.mesh.primitive_plane_add(size=200);floor=bpy.context.object;floor.data.materials.append(make_material('StudioFloor',(.15,.17,.20)))
for loc,power,size in [((4,6,9),1000,5),((-4,3,6),650,4),((1,-4,8),1000,4)]:
 bpy.ops.object.light_add(type='AREA',location=loc);ob=bpy.context.object;ob.data.energy=power;ob.data.shape='DISK';ob.data.size=size;ob.rotation_euler=(Vector((0,0,3))-ob.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add();cam=bpy.context.object;scene.camera=cam;cam.data.type='ORTHO';cam.data.ortho_scale=6.4
centerheight=(head.y+1)/2
for label,loc in [('frente',(7,17,8)),('espalda',(-7,-17,8))]:
 cam.location=loc;cam.rotation_euler=(Vector((0,0,centerheight))-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(OUT/('Vista_'+label+'.png'));bpy.ops.render.render(write_still=True)
stats={'version':2,'body_meshparts':14,'native_primitive_details':len(visual),'r15_body_parts':15,'motor6d':len(joints),'blender_vertices':len(skin.data.vertices),'blender_polygons':len(skin.data.polygons),'native_external_meshes':15,'studio_verified':False}
(OUT/'model_stats.json').write_text(json.dumps(stats,indent=2));(OUT/'scene.json').write_text(json.dumps({'version':2,'centers':{k:list(v) for k,v in centers.items()},'sizes':{k:list(v) for k,v in sizes.items()},'joints':[(n,a,b,list(p)) for n,a,b,p in joints],'details':visual,'body_meta':meta},indent=1));print('V2_STATS',json.dumps(stats))
